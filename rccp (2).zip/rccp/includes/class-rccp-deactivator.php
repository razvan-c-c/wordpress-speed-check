<?php

/**
 * Fired during plugin deactivation
 *
 * @link       razvancilibeanu.com
 * @since      1.0.0
 *
 * @package    Rccp
 * @subpackage Rccp/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Rccp
 * @subpackage Rccp/includes
 * @author     Razvan Cilibeanu <contact@razvancilibeanu.com>
 */
class Rccp_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
