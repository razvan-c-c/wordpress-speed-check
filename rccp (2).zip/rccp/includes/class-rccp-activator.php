<?php

/**
 * Fired during plugin activation
 *
 * @link       razvancilibeanu.com
 * @since      1.0.0
 *
 * @package    Rccp
 * @subpackage Rccp/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Rccp
 * @subpackage Rccp/includes
 * @author     Razvan Cilibeanu <contact@razvancilibeanu.com>
 */
class Rccp_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
